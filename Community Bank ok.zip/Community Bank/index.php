<?php
    error_reporting();
    session_start();
    header("Location:./Pages/index");
?>